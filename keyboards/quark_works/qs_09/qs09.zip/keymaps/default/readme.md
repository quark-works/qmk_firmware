# The default keymap for qs09
